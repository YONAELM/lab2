#ifndef DRONES_MANAGER_TEST
#define DRONES_MANAGER_TEST

#include "lab2_drones_manager.hpp"

#define ASSERT_TRUE(T) if (!(T)) return false;
#define ASSERT_FALSE(T) if ((T)) return false;

class DronesManagerTest {
public:
	// PURPOSE: New empty list is valid
	bool test1() {
		DronesManager manager;
		ASSERT_TRUE(manager.get_size() == 0)
		ASSERT_TRUE(manager.empty() == true)
		ASSERT_TRUE(manager.first == NULL)
		ASSERT_TRUE(manager.last == NULL)
	    return true;
	}
	
	// PURPOSE: insert_front() and insert_back() on zero-element list
	bool test2() {
		DronesManager manager1, manager2;
		manager1.insert_front(DronesManager::DroneRecord(100));
		manager2.insert_back(DronesManager::DroneRecord(100));
	    
		ASSERT_TRUE(manager1.get_size() == manager2.get_size() && manager1.get_size() == 1)
		ASSERT_TRUE(manager1.first != NULL && manager1.first == manager1.last)
		ASSERT_TRUE(manager2.first != NULL && manager2.first == manager2.last)
		ASSERT_TRUE(manager1.first->prev == NULL && manager1.last->next == NULL)
		ASSERT_TRUE(manager2.first->prev == NULL && manager2.last->next == NULL)
		ASSERT_TRUE(manager1.select(0) == manager2.select(0) && manager1.select(0) == DronesManager::DroneRecord(100))		
	    return true;
	}
	
	// TODO: Implement all of the test cases below
	
	// PURPOSE: select() and search() work properly
	bool test3() {
	    DronesManager manager1, manager2;
	    manager1.insert_front(DronesManager::DroneRecord(1));
	    manager1.insert_front(DronesManager::DroneRecord(2));
	    manager1.insert_front(DronesManager::DroneRecord(3));
	    manager1.insert_front(DronesManager::DroneRecord(4));

        ASSERT_TRUE(manager1.get_size() == 4);

        //Select tests
	    ASSERT_TRUE(manager1.select(1).droneID == 3);
	    ASSERT_TRUE(manager1.select(2).droneID == 2);
	    ASSERT_TRUE(manager1.select(5).droneID == 1);
	    ASSERT_TRUE(manager1.select(-5).droneID == 1);
        ASSERT_TRUE(manager2.select(0).droneID == 0);

	    //Search tests
        ASSERT_TRUE(manager1.search(1) == 3);
        ASSERT_TRUE(manager1.search(5) == 4);
        ASSERT_TRUE(manager1.search(0) == 4);
        ASSERT_TRUE(manager2.search(5) == 0);


        return true;
	}
	
	// PURPOSE: remove_front() and remove_back() on one-element list
	bool test4() {
	    DronesManager manager1, manager2;

	    manager1.insert_front(DronesManager :: DroneRecord(1));
	    manager2.insert_back(DronesManager :: DroneRecord(2));

	    ASSERT_TRUE(manager1.get_size() == 1 && manager2.get_size() == 1);
	    ASSERT_TRUE(manager1.remove_front() && manager1.get_size() == 0);
	    ASSERT_TRUE(manager1.first == NULL && manager1.last ==  NULL);
	    ASSERT_TRUE(manager2.remove_back() && manager2.get_size() == 0);
        ASSERT_TRUE(manager2.first == NULL && manager2.last ==  NULL);


        return true;
	}
	
	// PURPOSE: replace() and reverse_list() work properly
	bool test5() {
        DronesManager manager1, manager2, manager3;

        manager1.insert_front(DronesManager::DroneRecord(1));
        manager1.insert_back(DronesManager::DroneRecord(2));
        DronesManager :: DroneRecord new_record = DronesManager :: DroneRecord(3);

        //Replace tests
        ASSERT_TRUE(manager1.select(1).droneID == 2);
        ASSERT_TRUE(manager1.replace(1, new_record) && manager1.select(1).droneID == 3);
        ASSERT_TRUE(manager1.replace(0, DronesManager :: DroneRecord(4)) && manager1.select(0).droneID == 4);
        ASSERT_FALSE(manager2.replace(0, DronesManager :: DroneRecord(2)));
        ASSERT_TRUE(manager1.replace(manager1.get_size() - 1, DronesManager :: DroneRecord(5)) && manager1.select(manager1.get_size() - 1).droneID == 5);


        //Reverse List test
        manager2.insert_back(DronesManager :: DroneRecord(1));
        manager2.insert_back(DronesManager :: DroneRecord(2));
        manager2.insert_back(DronesManager :: DroneRecord(3));
        manager2.insert_back(DronesManager :: DroneRecord(4));
        manager2.insert_back(DronesManager :: DroneRecord(5));

        manager3.insert_front(DronesManager :: DroneRecord(1));
        manager3.insert_front(DronesManager :: DroneRecord(2));
        manager3.insert_front(DronesManager :: DroneRecord(3));
        manager3.insert_front(DronesManager :: DroneRecord(4));
        manager3.insert_front(DronesManager :: DroneRecord(5));

        ASSERT_TRUE( manager2.get_size() == manager3.get_size());
        for (int i = 0; i < manager2.get_size(); ++i) {
            ASSERT_TRUE( manager2.select(i) == manager3.select(manager3.get_size() - (i+1)));
        }
        return true;
	}
	
	// PURPOSE: insert_front() keeps moving elements forward
	bool test6() {
        DronesManager manager1, manager2;

        manager1.insert_front(DronesManager :: DroneRecord(5));
        manager1.insert_front(DronesManager :: DroneRecord(4));
        ASSERT_TRUE(manager1.select(0).droneID == 4 && manager1.select(1).droneID == 5);
        manager1.insert_front(DronesManager :: DroneRecord(3));
        ASSERT_TRUE(manager1.select(0).droneID == 3 && manager1.select(2).droneID == 5 )
        manager1.insert_front(DronesManager :: DroneRecord(2));
        ASSERT_TRUE(manager1.select(0).droneID == 2 && manager1.select(2).droneID == 4)
        manager1.insert_front(DronesManager :: DroneRecord(1));
        ASSERT_TRUE(manager1.select(0).droneID == 1 && manager1.select(manager1.get_size() - 1).droneID == 5)

        return true;
	}

    // PURPOSE: inserting at different positions in the list
    bool test7() {
        DronesManager manager1, manager2;
        manager1.insert_front(DronesManager :: DroneRecord(5));
        manager1.insert(DronesManager :: DroneRecord(4), 0);
        ASSERT_TRUE(manager1.select(0).droneID == 4 && manager1.select(1).droneID == 5);
        manager1.insert(DronesManager :: DroneRecord(3), 1);
        ASSERT_TRUE(manager1.select(2).droneID == 3); //check if inserting in the middle is valid
        //insert from the back might be a PROBLEM
        manager1.insert(DronesManager :: DroneRecord(2), 2);
        ASSERT_TRUE(manager1.select(3).droneID == 2); //check if inserting from the back is valid <-------------- Check if this actually works
        manager1.insert(DronesManager :: DroneRecord(1), 0);
        ASSERT_TRUE(manager1.select(1).droneID == 1); //check if inserting from the front is valid
        return true;
    }
    // PURPOSE: try to remove too many elements, then add a few elements
    bool test8() {
        DronesManager manager1, manager2;
        ASSERT_TRUE(manager1.insert_front(DronesManager :: DroneRecord(5)));
        ASSERT_TRUE(manager1.remove_back());
        ASSERT_FALSE(manager1.remove_back()); // check remove_back on the empty list
        ASSERT_FALSE(manager1.remove_front()); // check remove_front on the empty list
        ASSERT_TRUE(manager1.insert_front(DronesManager :: DroneRecord(5)));
        ASSERT_TRUE(manager1.insert_back(DronesManager :: DroneRecord(4)));
        ASSERT_TRUE(manager1.insert_front(DronesManager :: DroneRecord(3)));
        return true;
    }
    // PURPOSE: lots of inserts and deletes, some of them invalid
    bool test9() {
        DronesManager manager1, manager2;
        ASSERT_FALSE(manager1.remove_back()); //fail
        ASSERT_TRUE(manager1.insert_front(DronesManager :: DroneRecord(5)));
        ASSERT_TRUE(manager1.remove_back());
        ASSERT_TRUE(manager1.insert_front(DronesManager :: DroneRecord(5)));
        ASSERT_FALSE(manager1.remove(3)); // fail
        ASSERT_FALSE(manager1.insert(DronesManager :: DroneRecord(5), 2)); //fail
        ASSERT_TRUE(manager1.insert_front(DronesManager :: DroneRecord(4)));
        ASSERT_FALSE(manager1.insert(DronesManager :: DroneRecord(3), 2));
        return true;
    }
    // PURPOSE: inserts into an unsorted list, then sort the list
    bool test10() {
        DronesManagerSorted manager1, manager2;
        //ASC
        ASSERT_TRUE(manager1.insert_front(DronesManager :: DroneRecord(5)));
        ASSERT_TRUE(manager1.insert_back(DronesManager :: DroneRecord(4)));
        ASSERT_TRUE(manager1.insert_front(DronesManager :: DroneRecord(3)));
        ASSERT_TRUE(manager1.insert_back(DronesManager :: DroneRecord(2)));
//        manager1.sort_asc();
        ASSERT_TRUE(manager1.is_sorted_asc());
        //DESC
        ASSERT_TRUE(manager2.insert(DronesManager :: DroneRecord(2), 0));
        ASSERT_TRUE(manager2.insert_back(DronesManager :: DroneRecord(4)));
        ASSERT_TRUE(manager2.insert_front(DronesManager :: DroneRecord(3)));
        ASSERT_TRUE(manager2.insert_back(DronesManager :: DroneRecord(5)));
        manager1.sort_desc();
        ASSERT_TRUE(manager1.is_sorted_desc());
        return true;
    }
    // PURPOSE: insert and remove into sorted manager in ascending order
    bool test11() {
        DronesManagerSorted manager1, manager2;
        //ASC
        ASSERT_TRUE(manager1.insert(DronesManager :: DroneRecord(5), 0));
        ASSERT_TRUE(manager1.insert_back(DronesManager :: DroneRecord(4)));
        ASSERT_TRUE(manager1.insert_front(DronesManager :: DroneRecord(2)));
        ASSERT_TRUE(manager1.insert_back(DronesManager :: DroneRecord(1)));
        manager1.sort_asc();
        ASSERT_TRUE(manager1.is_sorted_asc());
        ASSERT_TRUE(manager1.insert_sorted_asc(DronesManager :: DroneRecord(3)));
        ASSERT_TRUE(manager1.select(2).droneID == 3);
        return true;
    }
    // PURPOSE: insert and remove into sorted manager in descending order
    bool test12() {
        DronesManagerSorted manager1, manager2;
        //DESC
        ASSERT_TRUE(manager2.insert(DronesManager :: DroneRecord(2), 0));
        ASSERT_TRUE(manager2.insert_back(DronesManager :: DroneRecord(4)));
        ASSERT_TRUE(manager2.insert_front(DronesManager :: DroneRecord(1)));
        ASSERT_TRUE(manager2.insert_back(DronesManager :: DroneRecord(5)));
        manager1.sort_desc();
        ASSERT_TRUE(manager1.is_sorted_desc());
        ASSERT_TRUE(manager1.insert_sorted_desc(DronesManager :: DroneRecord(3)));
        ASSERT_TRUE(manager1.select(2).droneID == 3);
        return true;
    }
};

#endif
